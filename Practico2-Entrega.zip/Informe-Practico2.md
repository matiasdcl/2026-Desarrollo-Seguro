# Práctico 2 - Mitigación de Vulnerabilidades de CWE

Este práctico se apoya en el ambiente armado en el Práctico 1 (Kali Linux, Docker y VS Code ya configurados). Repositorio base: `ucudal/2026-Desarrollo-Seguro` (rama `main`), forkeado y trabajado en la rama `practico-2`. La app es "CineBuscador", un buscador de funciones de cine.

Cada ejercicio corre en su propio contenedor Docker (`docker compose up -d --build` dentro de la carpeta del ejercicio). Para cada vulnerabilidad se muestra: en qué consiste, cómo se explota (PoC), qué cambio se hizo para mitigarla, y la verificación de que el mismo ataque ya no funciona.

---

## Ejercicio 1 - Inyección SQL (SQLi)

**Stack:** Python/Flask + SQLite. Se levanta con `docker compose -f Ejercicio1/docker-compose.yml up -d` y queda expuesto en `http://localhost:5000`.

La base se inicializa con `init_db.py`, que crea las tablas `peliculas` y `funciones` y las carga con datos de ejemplo.

![Script de inicialización de la base](Capturas/ej1-01-init-db-script.png)
![Datos de ejemplo cargados](Capturas/ej1-02-init-db-datos.png)
![Build del contenedor](Capturas/ej1-03-docker-build.png)
![docker-compose.yml del ejercicio](Capturas/ej1-04-docker-compose.png)

### Vulnerabilidad

En `app.py`, la función `buscar_funciones` arma la consulta SQL concatenando directamente el texto de búsqueda con un f-string:

```python
sql = f"SELECT ... WHERE peliculas.nombre LIKE '%{query}%' ORDER BY {...} {sort_dir}"
```

Como `query` entra crudo a la consulta, cualquier cosa que se escriba en el buscador se ejecuta como parte del SQL.

### Prueba de concepto

Con la app funcionando normalmente:

![App base](Capturas/ej1-05-app-base.png)
![Búsqueda normal](Capturas/ej1-06-busqueda-normal.png)

Se prueba primero cerrar la comilla y comentar el resto de la consulta con `%' --`, y después una inyección UNION SELECT para extraer datos de otra columna (el director de la película, filtrando por `peliculas`):

```
%' UNION SELECT nombre, director, 0 FROM peliculas --
```

![PoC: UNION SELECT filtrando datos de la tabla peliculas](Capturas/ej1-07-poc-union-select.png)

Se ve cómo el campo "fecha y hora" termina mostrando el nombre del director en vez de una fecha real, confirmando que la inyección se ejecutó y se pudo leer una columna distinta a la esperada.

### Mitigación

Se reemplazó la consulta armada con f-strings por una consulta parametrizada (con `?`), y se agregó una whitelist para `sort_by`/`sort_dir` ya que esos valores no se pueden parametrizar al ir en la cláusula `ORDER BY`:

```python
def buscar_funciones(query, sort_by='nombre', sort_dir='ASC'):
    db = get_db()

    columnas_validas = {'nombre': 'peliculas.nombre', 'fecha': 'funciones.fecha_hora'}
    sort_by = columnas_validas.get(sort_by, 'peliculas.nombre')
    sort_dir = 'ASC' if sort_dir.upper() != 'DESC' else 'DESC'

    sql = ("SELECT peliculas.nombre as pelicula, funciones.fecha_hora, "
           "(funciones.asientos_totales - funciones.asientos_ocupados) as disponibles "
           "FROM funciones "
           "JOIN peliculas ON funciones.pelicula_id = peliculas.id "
           "WHERE peliculas.nombre LIKE ? "
           f"ORDER BY {sort_by} {sort_dir}")

    return db.execute(sql, (f'%{query}%',)).fetchall()
```

Al usar `?`, el texto ingresado ya no se interpreta como código SQL, sea lo que sea lo que contenga.

### Verificación

Se repiten los dos payloads anteriores contra la app ya mitigada:

![Payload básico ya no rompe la consulta](Capturas/ej1-08-mitigacion-basico-ok.png)
![UNION SELECT ya no filtra datos](Capturas/ej1-09-mitigacion-union-ok.png)

En ambos casos la app responde "No se encontraron funciones", tratando el payload como un simple texto de búsqueda que no matchea ninguna película.

---

## Ejercicio 2 - Inyección SQL + Falta de Autorización

**Stack:** Python/Flask + SQLite, igual que el Ejercicio1 pero con un endpoint de edición de películas (`/edit/<id>`).

![App base](Capturas/ej2-01-app-base.png)

Este ejercicio tiene dos vulnerabilidades distintas en el mismo código.

### Vulnerabilidad 1: Falta de Autorización (Missing Authorization)

El endpoint `/edit/<id>` (tanto GET como POST) no tiene ningún chequeo de sesión o login. Cualquiera que conozca o adivine la URL puede editar cualquier película:

```python
@app.route('/edit/<int:pelicula_id>', methods=['POST'])
def edit_post(pelicula_id):
    ...
    db.execute('UPDATE peliculas SET nombre=?, genero=?, director=?, descripcion=? WHERE id=?', ...)
```

**PoC:** se entra directo a `http://localhost:5000/edit/1` sin haber iniciado sesión (porque ni siquiera existe un login), se cambia el nombre de la película a "Prueba-practico2" y se guarda:

![Edición sin estar autenticado](Capturas/ej2-02-poc-edit-sin-auth.png)

Buscando de nuevo se confirma que el cambio quedó guardado:

![La película quedó editada](Capturas/ej2-03-poc-edicion-confirmada.png)

### Vulnerabilidad 2: SQL Injection

Mismo patrón que el Ejercicio1, en la misma función `buscar_funciones`:

![PoC: payload básico de SQLi](Capturas/ej2-04-poc-sqli-basico.png)

Acá además se puede usar el UNION SELECT para extraer el `id` real de cada película (agregándolo como columna extra), que sirve justamente para saber qué IDs probar en `/edit/<id>`:

```
%' UNION SELECT nombre, director, 0, genero, id FROM peliculas --
```

![PoC: UNION SELECT extrayendo IDs de películas](Capturas/ej2-05-poc-sqli-union.png)

Esto muestra cómo las dos vulnerabilidades se pueden encadenar: con el SQLi se descubren los IDs, y con la falta de autorización se editan directamente.

### Mitigaciones

**SQLi:** se aplicó el mismo fix que en el Ejercicio1 (consulta parametrizada + whitelist de `ORDER BY`).

**Missing Authorization:** se agregó un login básico con sesión, y se protegió `/edit` con un decorador que exige estar autenticado. Las credenciales de admin se leen de variables de entorno (para no caer en otra vulnerabilidad: credenciales hardcodeadas):

```python
ADMIN_USER = os.environ.get('ADMIN_USER', 'admin')
ADMIN_PASS = os.environ.get('ADMIN_PASS', 'changeme')
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(24))

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('logueado'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form.get('usuario') == ADMIN_USER and request.form.get('password') == ADMIN_PASS:
            session['logueado'] = True
            return redirect(url_for('index'))
        error = 'Usuario o contraseña incorrectos'
    return render_template('login.html', error=error)
```

Y en los dos endpoints de edición:

```python
@app.route('/edit/<int:pelicula_id>', methods=['GET'])
@login_required
def edit_get(pelicula_id):
    ...

@app.route('/edit/<int:pelicula_id>', methods=['POST'])
@login_required
def edit_post(pelicula_id):
    ...
```

### Verificación

Los mismos payloads de SQLi ya no filtran nada:

![Payload básico ya no funciona](Capturas/ej2-06-mitigacion-sqli-basico-ok.png)
![UNION SELECT ya no funciona](Capturas/ej2-07-mitigacion-sqli-union-ok.png)

Y al intentar entrar a `/edit/1` sin sesión iniciada, ahora redirige al login:

![Redirección al login](Capturas/ej2-08-mitigacion-login.png)

Iniciando sesión con las credenciales correctas, sí se puede editar (el acceso está autorizado, no bloqueado por completo):

![Edición autorizada tras loguearse](Capturas/ej2-09-mitigacion-edit-autorizado.png)

---

## Ejercicio 3 - Recorrido de Directorios (Path Traversal)

**Stack:** Java/Spring Boot + Maven. Expone `http://localhost:8080`. La app permite subir un afiche para cada película (`POST /upload/{id}`), que se guarda en una carpeta `uploadDir` (`/uploads` dentro del contenedor).

![App base](Capturas/ej3-01-app-base.png)

### Vulnerabilidad

El controller usa `archivo.getOriginalFilename()` directamente para armar la ruta de destino, sin sanitizar. Si el nombre de archivo enviado contiene `../`, el archivo se termina escribiendo fuera de `uploadDir`.

### Prueba de concepto

Se sube un archivo indicando como nombre `../../../tmp/pwned.txt`, apuntando a escapar de la carpeta de uploads:

```bash
curl -v -F "afiche=@/tmp/test.txt;filename=../../../tmp/pwned.txt" http://localhost:8080/upload/1
```

![Subida del archivo con path traversal](Capturas/ej3-02-poc-upload-traversal.png)

Se confirma dentro del contenedor que el archivo terminó en `/tmp/pwned.txt`, fuera de la carpeta de uploads:

![Archivo encontrado fuera de /uploads](Capturas/ej3-03-poc-archivo-fuera-uploads.png)

### Mitigación

Se sanitiza el nombre del archivo quedándose solo con el nombre final (sin ninguna ruta), y además se valida que la ruta resuelta definitiva siga estando dentro de `uploadDir`:

```java
String filename = Paths.get(archivo.getOriginalFilename()).getFileName().toString();

Path uploadPath = Paths.get(uploadDir).toAbsolutePath().normalize();
Path destino = uploadPath.resolve(filename).normalize();

if (!destino.startsWith(uploadPath)) {
    throw new SecurityException("Ruta de archivo inválida");
}

Files.copy(archivo.getInputStream(), destino);
```

El mismo chequeo (`startsWith(uploadPath)`) se agregó también en el endpoint que sirve los archivos (`GET /uploads/{filename}`), para que tampoco se pueda leer un archivo fuera de esa carpeta.

![Código de la mitigación: getFileName()](Capturas/ej3-05-mitigacion-codigo-getfilename.png)

### Verificación

Se repite el mismo ataque contra la app ya mitigada:

![Intento de upload con path traversal, ya mitigado](Capturas/ej3-04-mitigacion-intento-upload.png)

Y se confirma que el archivo quedó dentro de `/uploads`, con el nombre reducido a solo `pwned3.txt` (se descartó todo el `../../../` del payload):

![El archivo quedó confinado dentro de /uploads](Capturas/ej3-06-mitigacion-archivo-contenido.png)

---

## Ejercicio 4 - Inyección de Comandos en Plantillas (Template/Command Injection vía SpEL)

**Stack:** Java/Spring Boot + Maven. `http://localhost:8080`. El buscador evalúa el texto ingresado como una expresión SpEL (Spring Expression Language) antes de usarlo para filtrar resultados.

![App base, con el aviso de que el buscador es vulnerable a SSTI](Capturas/ej4-01-app-base.png)

### Vulnerabilidad

El código evalúa la expresión con `StandardEvaluationContext`, que permite acceso completo a clases de Java (incluyendo `Runtime`), en vez de restringir la evaluación a operaciones simples.

### Prueba de concepto

Con una expresión simple ya se ve que el texto se evalúa como código, no como texto plano:

```
'hola'.toUpperCase()
```

![Expresión simple evaluada (hola -> HOLA)](Capturas/ej4-03-poc-spel-expresion-simple.png)

Con eso confirmado, se prueba ejecutar un comando del sistema:

```
T(java.lang.Runtime).getRuntime().exec('id')
```

![Ejecución de Runtime.exec devolviendo un Process](Capturas/ej4-02-poc-spel-exec-id.png)

La respuesta muestra un objeto `Process`, confirmando que el comando se ejecutó. Para dejar evidencia más contundente, se ejecuta un comando que vuelca el resultado a un archivo y se lee ese archivo dentro del contenedor:

```
T(java.lang.Runtime).getRuntime().exec(new java.lang.String[]{'sh','-c','id > /tmp/rce_proof.txt'})
```

```bash
docker exec cinebuscador4 cat /tmp/rce_proof.txt
```

![Contenido de /tmp/rce_proof.txt: uid=0(root)](Capturas/ej4-04-poc-rce-confirmado.png)

Se confirma ejecución de comandos arbitrarios con privilegios de root dentro del contenedor.

### Mitigación

Se cambió `StandardEvaluationContext` por `SimpleEvaluationContext` (que no permite invocar métodos de clases arbitrarias como `Runtime`), y se sumó una validación por whitelist de caracteres antes de evaluar la expresión, para descartar de entrada cualquier input que contenga sintaxis sospechosa.

### Verificación

Se repite el mismo payload de ejecución de comando (apuntando a un archivo distinto, `rce_proof2.txt`):

![El payload ya no se ejecuta como código](Capturas/ej4-05-mitigacion-payload-bloqueado.png)

Y se confirma que el archivo nunca se creó dentro del contenedor:

![El archivo nunca se creó](Capturas/ej4-06-mitigacion-archivo-no-creado.png)

---

## Ejercicio 5 - Credenciales Embebidas + Almacenamiento Inseguro

**Stack:** Java/Spring Boot + Maven + H2 (base en memoria). `http://localhost:8080`. Es un login/registro de usuarios para "CineBuscador".

![App base: login de CineBuscador](Capturas/ej5-01-app-base.png)

### Vulnerabilidad

En `EncryptionService.java`, las contraseñas se cifran (no se hashean) con AES-256/ECB, usando una clave estática embebida directamente en el código fuente:

```java
private static final String SECRET_KEY = "MySup3rS3cr3tK3y!2024CineBuscadorAES";
private static final String CIPHER_ALGO = "AES/ECB/PKCS5Padding";
```

Esto junta dos problemas: la clave es fija y está en el código (cualquiera con acceso al repo la tiene), y al ser cifrado (no hash) es reversible — quien tenga la clave puede recuperar la contraseña original de cualquier usuario. Como si fuera poco, `AuthController` devuelve la contraseña cifrada del usuario directamente en la respuesta del login.

### Prueba de concepto

Se registra un usuario de prueba:

![Registro de un usuario](Capturas/ej5-02-registro-victima.png)

Al iniciar sesión, la respuesta expone la contraseña cifrada en pantalla:

![La respuesta del login expone la contraseña cifrada](Capturas/ej5-03-poc-password-cifrada-expuesta.png)

Con ese valor cifrado y la clave hardcodeada (visible en el código fuente), se descifra directamente con `openssl` desde la terminal:

```bash
echo -n "mCAaG0yFFf+qhPjxwOkFQQ==" | base64 -d | \
openssl enc -aes-256-ecb -d -K $(printf '%s' 'MySup3rS3cr3tK3y!2024CineBuscadorAES' | head -c 32 | xxd -p -c 32) 2>&1
```

![Descifrado con openssl devolviendo la contraseña en texto plano](Capturas/ej5-04-poc-decrypt-openssl.png)

El comando devuelve `password123`, la contraseña real del usuario, confirmando que cualquiera con el código fuente puede recuperar todas las contraseñas almacenadas.

### Mitigación

Se reemplazó el cifrado reversible por un hash de un solo sentido con BCrypt, que no tiene "clave" que filtrar ni forma de revertirse:

```java
public class EncryptionService {
    private static final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public static String hash(String plaintext) {
        return encoder.encode(plaintext);
    }

    public static boolean matches(String plaintext, String hash) {
        return encoder.matches(plaintext, hash);
    }
}
```

Y se actualizó `AuthController` para comparar contra el hash en vez de descifrar, y se dejó de exponer la contraseña en la respuesta del login:

```java
@PostMapping("/login")
public String login(@RequestParam String username, @RequestParam String password, Model model) {
    User user = userRepository.findByUsername(username).orElse(null);

    if (user != null && EncryptionService.matches(password, user.getPassword())) {
        model.addAttribute("loginSuccess", true);
        model.addAttribute("welcomeUser", username);
        return "index";
    }
    model.addAttribute("loginError", "Usuario o contraseña incorrecta");
    addForms(model);
    return "index";
}

@PostMapping("/register")
public String register(@RequestParam String username, @RequestParam String password,
                       @RequestParam String confirmPwd, Model model) {
    ...
    nuevoUsuario.setPassword(EncryptionService.hash(password));
    userRepository.save(nuevoUsuario);
    ...
}
```

### Verificación

Se registra un nuevo usuario contra la app ya mitigada:

![Registro post-mitigación](Capturas/ej5-05-mitigacion-registro-victima2.png)
![Login post-mitigación](Capturas/ej5-06-mitigacion-login-hash-expuesto.png)

Y se consulta directamente la base H2 en memoria para confirmar cómo quedó guardada la contraseña:

![Consola H2: conectando a la base](Capturas/ej5-07-h2-console-login.png)
![Consola H2: tablas disponibles](Capturas/ej5-08-h2-console-conectado.png)

```sql
SELECT * FROM USUARIOS;
```

![La contraseña quedó guardada como hash bcrypt, no como texto cifrado reversible](Capturas/ej5-09-mitigacion-hash-bcrypt-bd.png)

La contraseña quedó guardada como `$2a$10$P9pe5I1pY1.URa1TlR/nHO5sYvn5/gtKUqIR.7racK6Gd8NTt.PNa` — un hash bcrypt. Ya no existe ninguna clave ni comando capaz de revertirlo a la contraseña original.

---

## Resumen

| Ejercicio | Vulnerabilidad | Mitigación |
|---|---|---|
| 1 | Inyección SQL | Consultas parametrizadas + whitelist en ORDER BY |
| 2 | Inyección SQL | Consultas parametrizadas + whitelist en ORDER BY |
| 2 | Falta de autorización | Login con sesión + decorador `login_required` |
| 3 | Recorrido de directorios | Sanitizar filename + validar que la ruta quede dentro de `uploadDir` |
| 4 | Inyección de comandos en plantillas (SpEL) | `SimpleEvaluationContext` + whitelist de caracteres |
| 5 | Credenciales embebidas + almacenamiento inseguro | BCrypt (hash de un solo sentido) en vez de AES/ECB con clave hardcodeada |
